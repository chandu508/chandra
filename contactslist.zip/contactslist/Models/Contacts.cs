using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace contactslist.Models
{

    [Table("user")]
    public class User {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id {get;set;}
        public string firstname {get;set;}
        public string lastname {get;set;}
        public string middlename {get;set;}
    }
   [Table("address")]
    public class Address {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id {get;set;}
        public string street {get;set;}
        public string city {get;set;}
        public string state {get;set;}
        public string zip {get;set;}
    }
    public class Contact {
        public User user {get;set;}
        public Address address {get;set;}
        
         [Column(TypeName = "nvarchar(24)")]
        public PhoneType phone {get;set;}
    }

    public enum PhoneType {
        home,work, mobile
    }
}
