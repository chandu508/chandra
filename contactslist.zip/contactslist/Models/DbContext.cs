using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace contactslist.Models
{
    public class SqlContext : DbContext
    {
        public DbSet<Contact> contacts { get; set; }
        public DbSet<User> users { get; set; }
        public DbSet<Address> addresses { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
             => options.UseSqlite("Data Source=test.db");


    }
}